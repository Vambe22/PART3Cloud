﻿using Microsoft.AspNetCore.Mvc;

namespace CldvPOEnew.Controllers.NewFolder
{
    public class EventController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
