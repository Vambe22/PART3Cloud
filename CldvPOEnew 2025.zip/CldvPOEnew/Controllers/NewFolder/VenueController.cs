﻿using Microsoft.AspNetCore.Mvc;

namespace CldvPOEnew.Controllers.NewFolder
{
    public class VenueController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
